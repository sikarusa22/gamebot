#from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

#clans_main_kb = InlineKeyboardMarkup(row_width=2)
#clans_main_kb.insert(InlineKeyboardButton("🔍 Страна", switch_inline_query_current_chat='Клан  '))
#clans_main_kb.insert(InlineKeyboardButton("📃 Список", switch_inline_query_current_chat='Кланы список '))
#clans_main_kb.add(InlineKeyboardButton(text='🏳️‍⚧️ Мой клан', switch_inline_query_current_chat='Мой клан '))
#clans_main_kb.insert(InlineKeyboardButton("👥 Вступить в клан", switch_inline_query_current_chat='Клан вступить '))

#clan_kb = InlineKeyboardMarkup(row_width=2)
#clan_kb.insert(InlineKeyboardButton(text='🪖 Воевать', switch_inline_query_current_chat='Клан объявить войну  '))
#clan_kb.insert(InlineKeyboardButton(text='😇 Создать союз', switch_inline_query_current_chat='Клан союз '))
#clan_kb.insert(InlineKeyboardButton(text='🪖 Армия', switch_inline_query_current_chat='Клан армия '))
#clan_kb.insert(InlineKeyboardButton(text='🛅 Снять полномочия', switch_inline_query_current_chat='Клан сняться '))


#def join_to_clan_kb(clan_name: str = ''):
#    kb = InlineKeyboardMarkup(row_width=1)
#    kb.add(InlineKeyboardButton(text='👆🏼 Стать соклановцем', switch_inline_query_current_chat=f'Клан вступить '
#                                                                                                 f'{clan_name} '))
#    return kb


#def get_clan_kb(clan_name: str = ''):
#    kb = InlineKeyboardMarkup(row_width=1)
#    kb.add(InlineKeyboardButton(text='🦋 Стать владельцем', switch_inline_query_current_chat=f'Стать владельцем '
#                                                                                             f'{clan_name} '))
#    return kb


#army_kb = InlineKeyboardMarkup(row_width=2)
#army_kb.insert(InlineKeyboardButton(text='🛒 Техника', switch_inline_query_current_chat='Клан техника  '))
#army_kb.insert(InlineKeyboardButton(text='🛒 Сняражение', switch_inline_query_current_chat='Клан снаряжение '))
#army_kb.insert(InlineKeyboardButton(text='🛒 Ракеты', switch_inline_query_current_chat='Клан ракеты '))
#army_kb.insert(InlineKeyboardButton(text='👮🏼 Готовность', switch_inline_query_current_chat='Клан готовность '))
