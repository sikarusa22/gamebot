
from decimal import Decimal
def to_str(money: int):
    f = Decimal(money)
    ff = round(f)
    ff = '{:,}'.format(ff).replace(',', '.')
    return f"<code>${ff}</code>"


def get_cash(money: str):
    res = money.replace('.', '').replace(',', '').replace(' ', '').replace('к', '000').replace('k', '000').replace('е', 'e').replace('K', '000').replace('К', '000').replace('Е', 'e').replace('$', '').replace('m', '000000')
    res2 = Decimal(float(res))
    res3 = round(res2)
    
    return res3
