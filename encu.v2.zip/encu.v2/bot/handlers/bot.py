from aiogram.types import Message

from utils.main.chats import Chat


async def bot_added_to_chat(message: Message):
    Chat(chat=message.chat)
    return await message.answer(f'🎖️ | Дарова! Спасибо вам за добавление меня в группу!\n🤨 | Пожалуйста, прочитайте мои команды и выдайте мне сначала админку!\n💡 | Канал новостей: @encu_gm_channel\n💡 | Игровой чат: @encu_gm_chat')
